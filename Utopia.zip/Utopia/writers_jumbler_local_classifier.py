from PIL import Image
import os
import sys
import ctypes
import json
import datetime
import random
import shutil
import threading
import traceback

import pygame
from pygame.locals import *

pygame.init()

WINDOW_WIDTH, WINDOW_HEIGHT = 1200, 800
ART_X, ART_Y, ART_WIDTH, ART_HEIGHT = 405, 45, 600, 600
MIN_ART_SIZE, MAX_ART_SIZE, DEFAULT_ART_SIZE = 20, 100, 30
FPS = 60

screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.NOFRAME, 32)
pygame.display.set_caption("Writers Jumbler - Local Art Categorizer")
clock = pygame.time.Clock()

TITLE_BAR_HEIGHT = 32
CLOSE_RECT = pygame.Rect(WINDOW_WIDTH - 46, 0, 46, TITLE_BAR_HEIGHT)
MINIMIZE_RECT = pygame.Rect(WINDOW_WIDTH - 92, 0, 46, TITLE_BAR_HEIGHT)
BASE_FOLDER = os.path.dirname(os.path.abspath(sys.argv[0]))
STATE_FILE = os.path.join(BASE_FOLDER, "writers_jumbler_autosave.json")
CATEGORY_FILE = os.path.join(BASE_FOLDER, "writers_jumbler_categories.json")
REFERENCE_FOLDER = os.path.join(BASE_FOLDER, "Reference_Images")
ART_FOLDER = os.path.join(BASE_FOLDER, "Art")
REFERENCE_CACHE = os.path.join(BASE_FOLDER, "writers_jumbler_reference_cache.pt")
IMAGE_EXTENSIONS = (".png", ".jpg", ".jpeg", ".webp", ".bmp")

fg_color = (0, 0, 0)
bg_color = (0, 0, 0)
canvas_color = (255, 255, 255)
squares = []
art_size = DEFAULT_ART_SIZE
auto_color_enabled = False
color_paint_mode_enabled = False
q_press_count = 0
classification_status = "C: classify current art | Shift+C: rebuild reference index"
classification_results = []
classification_busy = False
classifier = None


def get_native_window_handle():
    return pygame.display.get_wm_info().get("window")


def begin_native_window_drag():
    if sys.platform.startswith("win"):
        hwnd = get_native_window_handle()
        if hwnd:
            ctypes.windll.user32.ReleaseCapture()
            ctypes.windll.user32.SendMessageW(hwnd, 0x00A1, 2, 0)


def minimize_native_window():
    if sys.platform.startswith("win"):
        hwnd = get_native_window_handle()
        if hwnd:
            ctypes.windll.user32.ShowWindow(hwnd, 6)


def load_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            value = json.load(f)
        return value
    except (OSError, ValueError, json.JSONDecodeError):
        return default


saved_state = load_json(STATE_FILE, {"last_art_size": DEFAULT_ART_SIZE, "grids": {}})
category_records = load_json(CATEGORY_FILE, [])
if not isinstance(category_records, list):
    category_records = []


def write_json(path, value):
    temp = path + ".tmp"
    try:
        with open(temp, "w", encoding="utf-8") as f:
            json.dump(value, f, indent=2)
        os.replace(temp, path)
    except OSError as error:
        print("Could not write", path, error)


def write_state_file():
    write_json(STATE_FILE, saved_state)


def store_current_grid():
    if squares:
        saved_state["last_art_size"] = art_size
        saved_state.setdefault("grids", {})[str(art_size)] = [list(s["color"]) for s in squares]
        write_state_file()


def restored_last_art_size():
    try:
        value = int(saved_state.get("last_art_size", DEFAULT_ART_SIZE))
    except (TypeError, ValueError):
        value = DEFAULT_ART_SIZE
    return max(MIN_ART_SIZE, min(MAX_ART_SIZE, value))


def ensure_folders():
    os.makedirs(ART_FOLDER, exist_ok=True)
    os.makedirs(REFERENCE_FOLDER, exist_ok=True)
    for name in ("Dog", "Cat", "Bird", "Rabbit", "Horse", "Other"):
        os.makedirs(os.path.join(REFERENCE_FOLDER, name), exist_ok=True)


def make_timestamp_filename(ext, category=None):
    folder = ART_FOLDER
    if category:
        folder = os.path.join(ART_FOLDER, safe_folder_name(category))
    os.makedirs(folder, exist_ok=True)
    stamp = datetime.datetime.now().strftime("%m-%d-%Y-%I-%M-%S-%p")
    return os.path.join(folder, f"WritersJumbler_{art_size}x{art_size}_Art_{stamp}.{ext}")


def safe_folder_name(value):
    cleaned = "".join(c for c in str(value) if c.isalnum() or c in " _-").strip()
    return cleaned or "Unknown"


def get_cell_rect(row, col, local=False):
    left = (col * ART_WIDTH) // art_size
    right = ((col + 1) * ART_WIDTH) // art_size
    top = (row * ART_HEIGHT) // art_size
    bottom = ((row + 1) * ART_HEIGHT) // art_size
    if not local:
        left, right, top, bottom = left + ART_X, right + ART_X, top + ART_Y, bottom + ART_Y
    return pygame.Rect(left, top, right - left, bottom - top)


def get_square_draw_rect(row, col, local=False):
    cell = get_cell_rect(row, col, local)
    side = min(cell.width, cell.height)
    gap = 8 if side >= 20 else 4 if side >= 12 else 2 if side >= 8 else 1
    return pygame.Rect(cell.x + gap // 2, cell.y + gap // 2,
                       max(1, cell.width - gap), max(1, cell.height - gap))


def square_index(row, col):
    return row + col * art_size


def build_grid(new_size=None, save_previous=True):
    global art_size
    if new_size is not None:
        new_size = max(MIN_ART_SIZE, min(MAX_ART_SIZE, int(new_size)))
        if save_previous and squares and new_size != art_size:
            store_current_grid()
        art_size = new_size
    saved = saved_state.get("grids", {}).get(str(art_size))
    expected = art_size * art_size
    squares.clear()
    for col in range(art_size):
        for row in range(art_size):
            index = square_index(row, col)
            color = canvas_color
            if isinstance(saved, list) and len(saved) == expected:
                candidate = saved[index]
                if isinstance(candidate, list) and len(candidate) == 3:
                    color = tuple(max(0, min(255, int(v))) for v in candidate)
            squares.append({"row": row, "col": col, "color": color})
    saved_state["last_art_size"] = art_size
    write_state_file()


def marquee_south():
    for col in range(art_size):
        last = squares[square_index(art_size - 1, col)]["color"]
        for row in range(art_size - 1, 0, -1):
            squares[square_index(row, col)]["color"] = squares[square_index(row - 1, col)]["color"]
        squares[square_index(0, col)]["color"] = last


def marquee_north():
    for col in range(art_size):
        first = squares[square_index(0, col)]["color"]
        for row in range(art_size - 1):
            squares[square_index(row, col)]["color"] = squares[square_index(row + 1, col)]["color"]
        squares[square_index(art_size - 1, col)]["color"] = first


def marquee_east():
    for row in range(art_size):
        last = squares[square_index(row, art_size - 1)]["color"]
        for col in range(art_size - 1, 0, -1):
            squares[square_index(row, col)]["color"] = squares[square_index(row, col - 1)]["color"]
        squares[square_index(row, 0)]["color"] = last


def autoSymmetryPainter():
    for row in range(art_size):
        for col in range(art_size // 2):
            squares[square_index(row, art_size - col - 1)]["color"] = squares[square_index(row, col)]["color"]


def autoSymmetryPainterReverse():
    for row in range(art_size):
        for col in range(art_size // 2):
            squares[square_index(row, col)]["color"] = squares[square_index(row, art_size - col - 1)]["color"]


def auto_art_painter():
    for col in range(art_size):
        squares[square_index(random.randrange(art_size), col)]["color"] = fg_color


def generate_same_shade_color(base):
    delta = random.randint(-85, 85)
    return tuple(max(0, min(255, v + delta)) for v in base)


def autoColorCycle():
    global fg_color, q_press_count
    q_press_count += 1
    if q_press_count % 2 == 0:
        fg_color = generate_same_shade_color(fg_color)
        fg_group.set_color(fg_color)


def autoBlur():
    original = [s["color"] for s in squares]
    for col in range(art_size):
        for row in range(art_size):
            nearby = []
            for dc in (-1, 0, 1):
                for dr in (-1, 0, 1):
                    rr, cc = row + dr, col + dc
                    if 0 <= rr < art_size and 0 <= cc < art_size:
                        nearby.append(original[square_index(rr, cc)])
            squares[square_index(row, col)]["color"] = tuple(sum(v[c] for v in nearby) // len(nearby) for c in range(3))


def autoSharpen():
    original = [s["color"] for s in squares]
    for col in range(art_size):
        for row in range(art_size):
            center = original[square_index(row, col)]
            nearby = []
            for dc in (-1, 0, 1):
                for dr in (-1, 0, 1):
                    rr, cc = row + dr, col + dc
                    if 0 <= rr < art_size and 0 <= cc < art_size:
                        nearby.append(original[square_index(rr, cc)])
            avg = [sum(v[c] for v in nearby) / len(nearby) for c in range(3)]
            squares[square_index(row, col)]["color"] = tuple(max(0, min(255, round(center[c] * 2 - avg[c]))) for c in range(3))


def paint_9_color_blocks():
    for _ in range(9):
        r, c = random.randint(0, art_size - 3), random.randint(0, art_size - 3)
        color = generate_same_shade_color(fg_color) if color_paint_mode_enabled else fg_color
        for dr in range(3):
            for dc in range(3):
                squares[square_index(r + dr, c + dc)]["color"] = color


def render_art_surface():
    surface = pygame.Surface((ART_WIDTH, ART_HEIGHT))
    surface.fill((0, 0, 0))
    for sq in squares:
        pygame.draw.rect(surface, sq["color"], get_square_draw_rect(sq["row"], sq["col"], True))
    return surface


def surface_to_pil(surface=None):
    surface = surface or render_art_surface()
    data = pygame.image.tostring(surface, "RGB")
    return Image.frombytes("RGB", surface.get_size(), data)


class LocalArtClassifier:
    def __init__(self):
        self.torch = None
        self.model = None
        self.preprocess = None
        self.categories = []
        self.reference_vectors = None

    def load_model(self):
        if self.model is not None:
            return
        import torch
        from torchvision.models import mobilenet_v3_small, MobileNet_V3_Small_Weights
        self.torch = torch
        weights = MobileNet_V3_Small_Weights.DEFAULT
        base = mobilenet_v3_small(weights=weights)
        base.eval()
        self.model = torch.nn.Sequential(base.features, base.avgpool, torch.nn.Flatten(1))
        self.model.eval()
        self.preprocess = weights.transforms()

    def embedding(self, image):
        self.load_model()
        image = image.convert("RGB")
        tensor = self.preprocess(image).unsqueeze(0)
        with self.torch.inference_mode():
            vector = self.model(tensor)
            vector = self.torch.nn.functional.normalize(vector, dim=1)
        return vector.cpu()

    def reference_signature(self):
        rows = []
        for root, _, files in os.walk(REFERENCE_FOLDER):
            for filename in sorted(files):
                if filename.lower().endswith(IMAGE_EXTENSIONS):
                    path = os.path.join(root, filename)
                    try:
                        rows.append((os.path.relpath(path, REFERENCE_FOLDER), os.path.getmtime(path), os.path.getsize(path)))
                    except OSError:
                        pass
        return rows

    def build_index(self, force=False, progress=None):
        self.load_model()
        signature = self.reference_signature()
        if not force and os.path.exists(REFERENCE_CACHE):
            try:
                cache = self.torch.load(REFERENCE_CACHE, map_location="cpu", weights_only=False)
                if cache.get("signature") == signature:
                    self.categories = cache["categories"]
                    self.reference_vectors = cache["vectors"]
                    return len(self.categories)
            except Exception:
                pass
        grouped = {}
        total = len(signature)
        for number, (relative, _, _) in enumerate(signature, 1):
            category = relative.split(os.sep)[0]
            path = os.path.join(REFERENCE_FOLDER, relative)
            try:
                with Image.open(path) as image:
                    grouped.setdefault(category, []).append(self.embedding(image))
            except Exception as error:
                print("Skipped reference image:", path, error)
            if progress:
                progress(number, total)
        categories, vectors = [], []
        for category in sorted(grouped):
            category_vector = self.torch.cat(grouped[category], dim=0).mean(dim=0, keepdim=True)
            category_vector = self.torch.nn.functional.normalize(category_vector, dim=1)
            categories.append(category)
            vectors.append(category_vector)
        if not vectors:
            raise RuntimeError("No reference images found. Add images inside Reference_Images/category folders.")
        self.categories = categories
        self.reference_vectors = self.torch.cat(vectors, dim=0)
        self.torch.save({"signature": signature, "categories": categories, "vectors": self.reference_vectors}, REFERENCE_CACHE)
        return len(categories)

    def classify(self, image, force_rebuild=False):
        self.build_index(force=force_rebuild)
        query = self.embedding(image)
        scores = (query @ self.reference_vectors.T).squeeze(0)
        count = min(3, len(self.categories))
        values, indices = self.torch.topk(scores, k=count)
        results = []
        for value, index in zip(values.tolist(), indices.tolist()):
            results.append({"category": self.categories[index], "similarity": float(value)})
        return results


def start_classification(force_rebuild=False):
    global classification_busy, classification_status
    if classification_busy:
        return
    classification_busy = True
    classification_status = "Loading local MobileNetV3 Small..."
    image = surface_to_pil()

    def worker():
        global classifier, classification_busy, classification_status, classification_results
        try:
            if classifier is None:
                classifier = LocalArtClassifier()
            classification_status = "Building reference index..." if force_rebuild else "Analyzing artwork..."
            classification_results = classifier.classify(image, force_rebuild)
            best = classification_results[0]
            classification_status = f"Category: {best['category']} | similarity {best['similarity'] * 100:.1f}%"
        except ModuleNotFoundError:
            classification_results = []
            classification_status = "Install model: py -m pip install torch torchvision"
        except Exception as error:
            classification_results = []
            classification_status = "Classifier error: " + str(error)
            traceback.print_exc()
        finally:
            classification_busy = False

    threading.Thread(target=worker, daemon=True).start()


def save_category_record(filename):
    if not classification_results:
        return
    record = {
        "filename": os.path.relpath(filename, BASE_FOLDER),
        "created": datetime.datetime.now().isoformat(timespec="seconds"),
        "art_size": art_size,
        "category": classification_results[0]["category"],
        "similarity": round(classification_results[0]["similarity"], 6),
        "alternatives": classification_results[1:],
        "model": "MobileNetV3 Small reference similarity",
    }
    category_records.append(record)
    write_json(CATEGORY_FILE, category_records)


def save_picture_only():
    category = classification_results[0]["category"] if classification_results else None
    filename = make_timestamp_filename("png", category)
    pygame.image.save(render_art_surface(), filename)
    save_category_record(filename)
    print("Saved artwork:", filename)


def render_live_gif_frame(art_surface, frame_number, frame_count, filename):
    screen.fill(bg_color)
    screen.blit(art_surface, (ART_X, ART_Y))
    screen.blit(pygame.font.SysFont(None, 25).render(f"Saving animation: {frame_number} / {frame_count}", True, (255,255,255)), (ART_X, ART_Y + ART_HEIGHT + 12))
    screen.blit(pygame.font.SysFont(None, 25).render(os.path.basename(filename), True, (190,190,190)), (ART_X, ART_Y + ART_HEIGHT + 38))
    draw_custom_title_bar(screen)
    pygame.display.flip()


def save_gif(movement, count):
    frames, cancel = [], False
    filename = make_timestamp_filename("gif")
    for frame_index in range(count):
        movement()
        art_surface = render_art_surface()
        frames.append(surface_to_pil(art_surface))
        render_live_gif_frame(art_surface, frame_index + 1, count, filename)
        for event in pygame.event.get():
            if event.type in (QUIT, pygame.WINDOWCLOSE) or (event.type == KEYDOWN and event.key == K_ESCAPE):
                cancel = True
        if cancel:
            break
        pygame.time.delay(80)
    if frames and not cancel:
        frames[0].save(filename, save_all=True, append_images=frames[1:], duration=80, loop=0)
        store_current_grid()
        print("Saved animated GIF:", filename)


class Checkbox:
    def __init__(self, x, y, label, checked=False, callback=None):
        self.rect, self.label, self.checked, self.callback = pygame.Rect(x,y,20,20), label, checked, callback
        self.font = pygame.font.SysFont(None,24)
    def handle_event(self,event):
        if event.type == MOUSEBUTTONDOWN and self.rect.collidepoint(event.pos):
            self.checked = not self.checked
            if self.callback: self.callback(self.checked)
    def draw(self,surface):
        pygame.draw.rect(surface,(230,230,230),self.rect,2)
        if self.checked:
            pygame.draw.line(surface,(230,230,230),(self.rect.x+3,self.rect.y+10),(self.rect.x+9,self.rect.y+16),3)
            pygame.draw.line(surface,(230,230,230),(self.rect.x+9,self.rect.y+16),(self.rect.x+17,self.rect.y+3),3)
        surface.blit(self.font.render(self.label,True,(230,230,230)),(self.rect.x+40,self.rect.y-2))


class Slider:
    def __init__(self,x,y,color,callback):
        self.rect=pygame.Rect(x,y,300,20); self.knob=pygame.Rect(x,y,10,20)
        self.value=0; self.color=color; self.callback=callback; self.dragging=False
    def set_value(self,value):
        self.value=max(0,min(255,int(value))); self.knob.x=self.rect.x+int((self.value/255)*(self.rect.width-self.knob.width))
    def set_mouse(self,x):
        self.knob.x=max(self.rect.x,min(x,self.rect.right-self.knob.width)); self.value=int((self.knob.x-self.rect.x)/(self.rect.width-self.knob.width)*255); self.callback()
    def handle_event(self,e):
        if e.type==MOUSEBUTTONDOWN and self.rect.collidepoint(e.pos): self.dragging=True; self.set_mouse(e.pos[0])
        elif e.type==MOUSEBUTTONUP: self.dragging=False
        elif e.type==MOUSEMOTION and self.dragging: self.set_mouse(e.pos[0])
    def draw(self,s):
        pygame.draw.rect(s,self.color,self.rect,border_radius=4); pygame.draw.rect(s,(255,255,255),self.knob,border_radius=4)


class SliderGroup:
    def __init__(self,x,y,callback):
        self.callback=callback; self.r=Slider(x,y,(255,50,50),self.update); self.g=Slider(x,y+40,(50,255,50),self.update); self.b=Slider(x,y+80,(50,50,255),self.update)
    def update(self): self.callback((self.r.value,self.g.value,self.b.value))
    def set_color(self,c): self.r.set_value(c[0]); self.g.set_value(c[1]); self.b.set_value(c[2])
    def handle_event(self,e): self.r.handle_event(e); self.g.handle_event(e); self.b.handle_event(e)
    def draw(self,s): self.r.draw(s); self.g.draw(s); self.b.draw(s)


class Dropdown:
    def __init__(self,x,y,width):
        self.rect=pygame.Rect(x,y,width,34); self.values=list(range(20,101)); self.selected=art_size; self.open=False
        self.scroll=max(0,min(len(self.values)-7,self.values.index(self.selected)-3)); self.font=pygame.font.SysFont(None,24)
    def handle_event(self,e):
        if e.type==MOUSEBUTTONDOWN and e.button==1:
            if self.rect.collidepoint(e.pos): self.open=not self.open; return True
            if self.open:
                lr=pygame.Rect(self.rect.x,self.rect.bottom,self.rect.width,196)
                if lr.collidepoint(e.pos):
                    i=self.scroll+(e.pos[1]-lr.y)//28
                    if i<len(self.values): self.selected=self.values[i]; build_grid(self.selected)
                    self.open=False; return True
                self.open=False
        if e.type==MOUSEWHEEL and self.open:
            self.scroll=max(0,min(len(self.values)-7,self.scroll-e.y)); return True
        return False
    def draw(self,s):
        pygame.draw.rect(s,(35,35,35),self.rect,border_radius=5); pygame.draw.rect(s,(210,210,210),self.rect,2,border_radius=5)
        s.blit(self.font.render(f"{self.selected} x {self.selected}",True,(245,245,245)),(self.rect.x+10,self.rect.y+7))
        if self.open:
            lr=pygame.Rect(self.rect.x,self.rect.bottom,self.rect.width,196); pygame.draw.rect(s,(24,24,24),lr); pygame.draw.rect(s,(220,220,220),lr,2)
            for n,i in enumerate(range(self.scroll,min(self.scroll+7,len(self.values)))):
                s.blit(self.font.render(f"{self.values[i]} x {self.values[i]}",True,(245,245,245)),(lr.x+8,lr.y+n*28+4))


def set_fg(c):
    global fg_color; fg_color=c

def set_bg(c):
    global bg_color; bg_color=c

def set_auto(v):
    global auto_color_enabled; auto_color_enabled=v

def set_shade(v):
    global color_paint_mode_enabled; color_paint_mode_enabled=v


fg_group=SliderGroup(50,40,set_fg); bg_group=SliderGroup(50,180,set_bg)
auto_box=Checkbox(50,420,"Auto Color Cycle",False,set_auto)
shade_box=Checkbox(50,460,"Color Paint Mode",False,set_shade)
dropdown=Dropdown(50,550,300)
font=pygame.font.SysFont(None,22)
small_font=pygame.font.SysFont(None,20)


def paint_at(pos,erase=False):
    mx,my=pos
    if not (ART_X<=mx<ART_X+ART_WIDTH and ART_Y<=my<ART_Y+ART_HEIGHT): return
    col=min(art_size-1,((mx-ART_X)*art_size)//ART_WIDTH); row=min(art_size-1,((my-ART_Y)*art_size)//ART_HEIGHT)
    squares[square_index(row,col)]["color"] = canvas_color if erase else (generate_same_shade_color(fg_color) if color_paint_mode_enabled else fg_color)
    store_current_grid()


def draw_custom_title_bar(surface):
    pygame.draw.rect(surface,(28,28,32),(0,0,WINDOW_WIDTH,TITLE_BAR_HEIGHT)); pygame.draw.line(surface,(75,75,82),(0,TITLE_BAR_HEIGHT-1),(WINDOW_WIDTH,TITLE_BAR_HEIGHT-1),1)
    surface.blit(pygame.font.SysFont(None,22).render("Writers Jumbler",True,(235,235,235)),(12,7))
    pygame.draw.rect(surface,(55,55,60),MINIMIZE_RECT); pygame.draw.line(surface,(235,235,235),(MINIMIZE_RECT.centerx-7,MINIMIZE_RECT.centery+5),(MINIMIZE_RECT.centerx+7,MINIMIZE_RECT.centery+5),2)
    pygame.draw.rect(surface,(150,45,45),CLOSE_RECT); pygame.draw.line(surface,(255,255,255),(CLOSE_RECT.centerx-6,CLOSE_RECT.centery-6),(CLOSE_RECT.centerx+6,CLOSE_RECT.centery+6),2); pygame.draw.line(surface,(255,255,255),(CLOSE_RECT.centerx+6,CLOSE_RECT.centery-6),(CLOSE_RECT.centerx-6,CLOSE_RECT.centery+6),2)


def draw_classifier_status():
    y = ART_Y + ART_HEIGHT + 12
    color = (255,215,90) if classification_busy else (220,235,220)
    screen.blit(font.render(classification_status, True, color), (ART_X, y))
    for i, result in enumerate(classification_results[:3]):
        text = f"{i+1}. {result['category']}  {result['similarity']*100:.1f}%"
        screen.blit(small_font.render(text, True, (190,190,200)), (ART_X, y + 25 + i*20))


def main():
    ensure_folders(); build_grid(restored_last_art_size(), save_previous=False)
    running=True
    while running:
        for event in pygame.event.get():
            ignored=(pygame.WINDOWMOVED,pygame.WINDOWMINIMIZED,pygame.WINDOWMAXIMIZED,pygame.WINDOWRESTORED,pygame.WINDOWSHOWN,pygame.WINDOWHIDDEN,pygame.WINDOWEXPOSED,pygame.WINDOWFOCUSGAINED,pygame.WINDOWFOCUSLOST,pygame.WINDOWENTER,pygame.WINDOWLEAVE,pygame.WINDOWRESIZED,pygame.WINDOWSIZECHANGED)
            if event.type in ignored: continue
            changed=getattr(pygame,"WINDOWDISPLAYCHANGED",None)
            if changed is not None and event.type==changed: continue
            if event.type in (QUIT,pygame.WINDOWCLOSE): running=False; continue
            if event.type==MOUSEBUTTONDOWN and event.button==1:
                if CLOSE_RECT.collidepoint(event.pos): running=False; continue
                if MINIMIZE_RECT.collidepoint(event.pos): minimize_native_window(); continue
                if event.pos[1]<TITLE_BAR_HEIGHT: begin_native_window_drag(); continue
            used=dropdown.handle_event(event)
            if not used and not dropdown.open:
                fg_group.handle_event(event); bg_group.handle_event(event); auto_box.handle_event(event); shade_box.handle_event(event)
                if event.type==MOUSEBUTTONDOWN:
                    if event.button==1: paint_at(event.pos)
                    elif event.button==3: paint_at(event.pos,True)
            if event.type==KEYDOWN and not dropdown.open:
                if event.key==K_ESCAPE: running=False
                elif event.key==K_q: auto_art_painter(); autoColorCycle() if auto_color_enabled else None; store_current_grid()
                elif event.key==K_w: autoSymmetryPainter(); store_current_grid()
                elif event.key==K_e: autoSymmetryPainterReverse(); store_current_grid()
                elif event.key==K_p:
                    for square in squares: square["color"]=canvas_color
                    store_current_grid()
                elif event.key==K_b: autoBlur(); store_current_grid()
                elif event.key==K_h: autoSharpen(); store_current_grid()
                elif event.key==K_j: paint_9_color_blocks(); store_current_grid()
                elif event.key==K_c: start_classification(bool(event.mod & KMOD_SHIFT))
                elif event.key==K_s: save_picture_only()
                elif event.key==K_l: save_gif(marquee_south,art_size)
                elif event.key==K_k: save_gif(marquee_east,art_size)
                elif event.key==K_n: save_gif(lambda:(marquee_east(),marquee_south()),art_size*2)
                elif event.key==K_m: save_gif(lambda:(marquee_east(),marquee_north()),art_size*2)
        screen.fill(bg_color)
        buttons=pygame.mouse.get_pressed(3)
        if not dropdown.open:
            if buttons[0]: paint_at(pygame.mouse.get_pos())
            elif buttons[2]: paint_at(pygame.mouse.get_pos(),True)
        pygame.draw.rect(screen,(0,0,0),(ART_X,ART_Y,ART_WIDTH,ART_HEIGHT))
        for sq in squares: pygame.draw.rect(screen,sq["color"],get_square_draw_rect(sq["row"],sq["col"]))
        fg_group.draw(screen); bg_group.draw(screen); auto_box.draw(screen); shade_box.draw(screen)
        screen.blit(font.render("Art Size 20-100 | C classify | Shift+C rebuild",True,(230,230,230)),(50,520))
        dropdown.draw(screen); draw_classifier_status(); draw_custom_title_bar(screen)
        pygame.display.flip(); clock.tick(FPS)
    store_current_grid(); pygame.quit(); sys.exit()


if __name__=="__main__":
    main()
