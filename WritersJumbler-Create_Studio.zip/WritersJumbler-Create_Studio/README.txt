WritersJumbler specArt Desktop X Y - Grid Pack 20 through 100

Open START_HERE.html.

Includes every square grid size from 20 x 20 to 100 x 100, increasing by 1.
Each page includes:
- Template Art: Diamond Chopped
- Template Art 2: Big X Chopped
- Blank grid
- Upload Custom Image and automatically chop it across the selected grid
- Supports browser-readable image formats including PNG, JPG, WEBP, GIF, and BMP where supported
- Cell size control
- Click-to-toggle cells
- Export active template cells as JSON

Integration:
Copy this whole folder into OfflineWebViewer/WritersJumbler/ and add a link to START_HERE.html from your existing index if desired.
All files work offline. No external libraries or web calls are used.

Photo Effects Studio:
- Upload JPG, PNG, WEBP, GIF first-frame, or another browser-readable image
- Brightness, contrast, saturation, hue, blur, grayscale, sepia, invert, and opacity
- Presets, rotation, horizontal/vertical flip
- Copy generated CSS filter settings
- Save the edited result as PNG

WritersJumbler Photo Effects now includes image upload, live effects, presets, CSS copy, and PNG export. The separate Photo Effects Studio remains included.

Art rearrangement:
- Each grid 20-100 loads its matching shared/art/artXX.js file.
- Upload a custom image, then use Rearrange artXX.js to shuffle its chopped pieces.
- Restore Arrangement puts all pieces back into the original image order.
- WritersJumbler Photo Effects also includes Rearrange Pieces and Restore Arrangement while separate studios remain.

Updated cut/rearrange behavior:
- Uploaded images are divided into the full grid count of independent visual pieces.
- artXX.js rearranges the pieces already visible, including uploaded images, Diamond, Big X, blank/manual art, and a previously rearranged state.
- Repeated presses rearrange the current arrangement instead of restarting from the original.
- Restore returns to the snapshot captured before the first rearrangement.
- WritersJumbler Photo Effects cuts uploads into 36 pieces, rearranges the current order repeatedly, and Save PNG exports that rearranged result.

Column-only symmetric rearrangement:
- Rearrangement moves complete vertical columns only.
- The right side uses the matching mirrored movement from the left side.
- For odd grid sizes, the center column remains in place.
- Repeated presses rearrange the current column arrangement.
- Restore returns to the arrangement before the first column rearrangement.

Hollow diamonds and thin X templates are included in counts 1 through 5. Column-only mirrored rearrangement remains active.

WritersJumbler Photo Effects grid selector:
- Pull-down includes every size from 20 x 20 through 100 x 100 by 1.
- Cut into Blocks divides the uploaded image conceptually into N x N blocks.
- Rearrangement moves full vertical block columns only, mirrored the same on each side.
- Restore returns the original column order.
- Save PNG exports the selected block-grid arrangement with photo effects.

Final WritersJumbler Photo Effects arrangement update:
- WritersJumbler Photo Effects cuts the uploaded photo into the selected N x N block grid.
- Every row rearranges its own columns independently.
- Within each row, the right side mirrors the left-side column movement.
- Repeated rearrange operations continue from the current row arrangements.
- Custom image upload was removed from all separate Grid Studio pages.
- Image upload remains available in WritersJumbler Photo Effects and the separate Photo Effects Studio.

True-square WritersJumbler Photo Effects cutter:
- The uploaded image is center-cropped to a square workspace.
- The selected 20 x 20 through 100 x 100 size creates actual equal square pieces.
- Rearrange Small Squares Like Grid rearranges the squares independently in each row.
- The right half mirrors the left half within every row.
- Repeated rearranging starts from the current square positions.
- Separate Grid Studio pages remain without image upload.

Grid Studio: Export Template JSON was removed and replaced with Save as PNG on all 81 grid pages.

Full-grid PNG export:
- Save Complete Grid as PNG exports every cell from the current grid into one 2000 x 2000 PNG.
- The saved image includes the entire grid from top-left through bottom-right, including current templates and rearrangement.

Performance update:
- Grid Studio now uses one HTML canvas instead of up to 10,000 image elements.
- Templates, manual cell toggles, mirrored column rearrangement, restore, and full-grid PNG export are drawn directly on canvas.
- PNG export no longer loads thousands of tile images individually.

Web Worker and low-memory update:
- Rendering uses an inline Blob Web Worker and OffscreenCanvas when supported, with automatic main-thread fallback.
- Low Memory Mode reduces preview resolution to 600 pixels and PNG export to 1200 pixels.
- Low Memory Mode avoids keeping a second grid snapshot; Restore regenerates the selected template.
- Render requests are batched through requestAnimationFrame.

Branding update: the overall grid product is WritersJumbler Create Studio; the image/photo workspace is WritersJumbler Photo Effects. Saved PNG names use the matching branding.

Photo Effects performance: Cut and Rearrange now uses a Web Worker with OffscreenCanvas when available. Low Memory Mode uses an 800px source, 600px preview, and 900px PNG. Automatic main-thread fallback remains available.
