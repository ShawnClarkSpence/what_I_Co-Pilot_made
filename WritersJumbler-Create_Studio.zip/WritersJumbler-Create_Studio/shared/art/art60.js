// WritersJumbler art60.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art60() {
  if (window.WJ_GRID_SIZE !== 60) return;
  rearrangeCurrentArt((Date.now() ^ 60 ^ (60 * 60)) >>> 0);
}
