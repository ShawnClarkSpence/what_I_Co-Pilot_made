// WritersJumbler art26.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art26() {
  if (window.WJ_GRID_SIZE !== 26) return;
  rearrangeCurrentArt((Date.now() ^ 26 ^ (26 * 26)) >>> 0);
}
