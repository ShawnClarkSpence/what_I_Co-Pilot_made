// WritersJumbler art25.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art25() {
  if (window.WJ_GRID_SIZE !== 25) return;
  rearrangeCurrentArt((Date.now() ^ 25 ^ (25 * 25)) >>> 0);
}
