// WritersJumbler art40.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art40() {
  if (window.WJ_GRID_SIZE !== 40) return;
  rearrangeCurrentArt((Date.now() ^ 40 ^ (40 * 40)) >>> 0);
}
