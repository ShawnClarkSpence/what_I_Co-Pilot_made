// WritersJumbler art28.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art28() {
  if (window.WJ_GRID_SIZE !== 28) return;
  rearrangeCurrentArt((Date.now() ^ 28 ^ (28 * 28)) >>> 0);
}
