// WritersJumbler art89.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art89() {
  if (window.WJ_GRID_SIZE !== 89) return;
  rearrangeCurrentArt((Date.now() ^ 89 ^ (89 * 89)) >>> 0);
}
