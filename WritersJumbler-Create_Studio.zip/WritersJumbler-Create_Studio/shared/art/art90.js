// WritersJumbler art90.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art90() {
  if (window.WJ_GRID_SIZE !== 90) return;
  rearrangeCurrentArt((Date.now() ^ 90 ^ (90 * 90)) >>> 0);
}
