// WritersJumbler art91.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art91() {
  if (window.WJ_GRID_SIZE !== 91) return;
  rearrangeCurrentArt((Date.now() ^ 91 ^ (91 * 91)) >>> 0);
}
