// WritersJumbler art76.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art76() {
  if (window.WJ_GRID_SIZE !== 76) return;
  rearrangeCurrentArt((Date.now() ^ 76 ^ (76 * 76)) >>> 0);
}
