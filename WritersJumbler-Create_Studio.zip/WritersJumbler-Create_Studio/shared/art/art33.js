// WritersJumbler art33.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art33() {
  if (window.WJ_GRID_SIZE !== 33) return;
  rearrangeCurrentArt((Date.now() ^ 33 ^ (33 * 33)) >>> 0);
}
