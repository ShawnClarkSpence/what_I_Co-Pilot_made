// WritersJumbler art21.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art21() {
  if (window.WJ_GRID_SIZE !== 21) return;
  rearrangeCurrentArt((Date.now() ^ 21 ^ (21 * 21)) >>> 0);
}
