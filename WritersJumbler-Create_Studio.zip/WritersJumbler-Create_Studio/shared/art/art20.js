// WritersJumbler art20.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art20() {
  if (window.WJ_GRID_SIZE !== 20) return;
  rearrangeCurrentArt((Date.now() ^ 20 ^ (20 * 20)) >>> 0);
}
