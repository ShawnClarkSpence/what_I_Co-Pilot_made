// WritersJumbler art38.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art38() {
  if (window.WJ_GRID_SIZE !== 38) return;
  rearrangeCurrentArt((Date.now() ^ 38 ^ (38 * 38)) >>> 0);
}
