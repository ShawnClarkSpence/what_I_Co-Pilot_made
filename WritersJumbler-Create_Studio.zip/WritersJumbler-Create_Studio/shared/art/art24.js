// WritersJumbler art24.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art24() {
  if (window.WJ_GRID_SIZE !== 24) return;
  rearrangeCurrentArt((Date.now() ^ 24 ^ (24 * 24)) >>> 0);
}
