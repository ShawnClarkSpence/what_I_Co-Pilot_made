// WritersJumbler art72.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art72() {
  if (window.WJ_GRID_SIZE !== 72) return;
  rearrangeCurrentArt((Date.now() ^ 72 ^ (72 * 72)) >>> 0);
}
