// WritersJumbler art98.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art98() {
  if (window.WJ_GRID_SIZE !== 98) return;
  rearrangeCurrentArt((Date.now() ^ 98 ^ (98 * 98)) >>> 0);
}
