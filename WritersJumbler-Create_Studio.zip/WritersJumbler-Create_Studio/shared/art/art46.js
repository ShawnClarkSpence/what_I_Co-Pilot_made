// WritersJumbler art46.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art46() {
  if (window.WJ_GRID_SIZE !== 46) return;
  rearrangeCurrentArt((Date.now() ^ 46 ^ (46 * 46)) >>> 0);
}
