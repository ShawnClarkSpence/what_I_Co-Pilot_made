// WritersJumbler art77.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art77() {
  if (window.WJ_GRID_SIZE !== 77) return;
  rearrangeCurrentArt((Date.now() ^ 77 ^ (77 * 77)) >>> 0);
}
