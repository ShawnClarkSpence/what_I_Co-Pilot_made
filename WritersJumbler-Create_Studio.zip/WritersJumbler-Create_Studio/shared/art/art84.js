// WritersJumbler art84.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art84() {
  if (window.WJ_GRID_SIZE !== 84) return;
  rearrangeCurrentArt((Date.now() ^ 84 ^ (84 * 84)) >>> 0);
}
