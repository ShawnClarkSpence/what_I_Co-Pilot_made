// WritersJumbler art80.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art80() {
  if (window.WJ_GRID_SIZE !== 80) return;
  rearrangeCurrentArt((Date.now() ^ 80 ^ (80 * 80)) >>> 0);
}
