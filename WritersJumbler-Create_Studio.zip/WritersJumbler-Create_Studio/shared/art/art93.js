// WritersJumbler art93.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art93() {
  if (window.WJ_GRID_SIZE !== 93) return;
  rearrangeCurrentArt((Date.now() ^ 93 ^ (93 * 93)) >>> 0);
}
