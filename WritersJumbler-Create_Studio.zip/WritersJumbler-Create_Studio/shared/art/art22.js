// WritersJumbler art22.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art22() {
  if (window.WJ_GRID_SIZE !== 22) return;
  rearrangeCurrentArt((Date.now() ^ 22 ^ (22 * 22)) >>> 0);
}
