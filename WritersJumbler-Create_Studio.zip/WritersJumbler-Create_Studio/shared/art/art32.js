// WritersJumbler art32.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art32() {
  if (window.WJ_GRID_SIZE !== 32) return;
  rearrangeCurrentArt((Date.now() ^ 32 ^ (32 * 32)) >>> 0);
}
