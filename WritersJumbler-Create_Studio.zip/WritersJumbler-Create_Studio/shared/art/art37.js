// WritersJumbler art37.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art37() {
  if (window.WJ_GRID_SIZE !== 37) return;
  rearrangeCurrentArt((Date.now() ^ 37 ^ (37 * 37)) >>> 0);
}
