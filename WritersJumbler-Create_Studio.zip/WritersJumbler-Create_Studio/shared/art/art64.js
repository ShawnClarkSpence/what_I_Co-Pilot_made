// WritersJumbler art64.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art64() {
  if (window.WJ_GRID_SIZE !== 64) return;
  rearrangeCurrentArt((Date.now() ^ 64 ^ (64 * 64)) >>> 0);
}
