// WritersJumbler art66.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art66() {
  if (window.WJ_GRID_SIZE !== 66) return;
  rearrangeCurrentArt((Date.now() ^ 66 ^ (66 * 66)) >>> 0);
}
