// WritersJumbler art73.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art73() {
  if (window.WJ_GRID_SIZE !== 73) return;
  rearrangeCurrentArt((Date.now() ^ 73 ^ (73 * 73)) >>> 0);
}
