// WritersJumbler art88.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art88() {
  if (window.WJ_GRID_SIZE !== 88) return;
  rearrangeCurrentArt((Date.now() ^ 88 ^ (88 * 88)) >>> 0);
}
