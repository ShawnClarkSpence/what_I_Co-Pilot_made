// WritersJumbler art100.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art100() {
  if (window.WJ_GRID_SIZE !== 100) return;
  rearrangeCurrentArt((Date.now() ^ 100 ^ (100 * 100)) >>> 0);
}
