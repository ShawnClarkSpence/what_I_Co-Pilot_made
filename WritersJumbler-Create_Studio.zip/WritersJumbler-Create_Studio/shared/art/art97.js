// WritersJumbler art97.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art97() {
  if (window.WJ_GRID_SIZE !== 97) return;
  rearrangeCurrentArt((Date.now() ^ 97 ^ (97 * 97)) >>> 0);
}
