// WritersJumbler art87.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art87() {
  if (window.WJ_GRID_SIZE !== 87) return;
  rearrangeCurrentArt((Date.now() ^ 87 ^ (87 * 87)) >>> 0);
}
