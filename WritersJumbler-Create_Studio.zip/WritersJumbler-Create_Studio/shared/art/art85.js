// WritersJumbler art85.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art85() {
  if (window.WJ_GRID_SIZE !== 85) return;
  rearrangeCurrentArt((Date.now() ^ 85 ^ (85 * 85)) >>> 0);
}
