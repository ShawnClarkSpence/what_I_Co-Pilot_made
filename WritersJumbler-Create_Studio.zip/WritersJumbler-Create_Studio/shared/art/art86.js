// WritersJumbler art86.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art86() {
  if (window.WJ_GRID_SIZE !== 86) return;
  rearrangeCurrentArt((Date.now() ^ 86 ^ (86 * 86)) >>> 0);
}
