// WritersJumbler art36.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art36() {
  if (window.WJ_GRID_SIZE !== 36) return;
  rearrangeCurrentArt((Date.now() ^ 36 ^ (36 * 36)) >>> 0);
}
