// WritersJumbler art27.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art27() {
  if (window.WJ_GRID_SIZE !== 27) return;
  rearrangeCurrentArt((Date.now() ^ 27 ^ (27 * 27)) >>> 0);
}
