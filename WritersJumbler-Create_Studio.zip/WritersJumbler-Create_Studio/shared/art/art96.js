// WritersJumbler art96.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art96() {
  if (window.WJ_GRID_SIZE !== 96) return;
  rearrangeCurrentArt((Date.now() ^ 96 ^ (96 * 96)) >>> 0);
}
