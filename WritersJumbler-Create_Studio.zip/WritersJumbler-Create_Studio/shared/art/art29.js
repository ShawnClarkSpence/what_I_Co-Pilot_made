// WritersJumbler art29.js
// Rearranges whole columns only. The right side mirrors the left-side column movement.
function art29() {
  if (window.WJ_GRID_SIZE !== 29) return;
  rearrangeCurrentArt((Date.now() ^ 29 ^ (29 * 29)) >>> 0);
}
