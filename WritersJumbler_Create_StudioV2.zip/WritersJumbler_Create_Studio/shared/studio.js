const N=window.WJ_GRID_SIZE,c=document.getElementById('grid'),x=c.getContext('2d'),st=document.getElementById('status'),lm=document.getElementById('lowMemory'),rowMode=document.getElementById('rowMode'),columnMode=document.getElementById('columnMode');let S=1000,g=new Uint8Array(N*N),orig=null,w=null,j=0,pending=false,mode='diamond1';const C=['#07111f','#238cff','#73e7ff','#fff'];const wc=`onmessage=e=>{let m=e.data,a=new Uint8Array(m.a),c=new OffscreenCanvas(m.s,m.s),x=c.getContext('2d'),t=m.s/m.n;x.fillStyle='#07111f';x.fillRect(0,0,m.s,m.s);for(let r=0;r<m.n;r++)for(let q=0;q<m.n;q++){x.fillStyle=['#07111f','#238cff','#73e7ff','#fff'][a[r*m.n+q]];x.fillRect(q*t,r*t,t+.2,t+.2)}let b=c.transferToImageBitmap();postMessage({i:m.i,b},[b])}`;function worker(){if(w)return true;try{w=new Worker(URL.createObjectURL(new Blob([wc])));w.onmessage=e=>{if(e.data.i!==j)return;x.drawImage(e.data.b,0,0);e.data.b.close();pending=false};return true}catch{return false}}function tile(r,q,k){let X=(q+.5)/N*2-1,Y=(r+.5)/N*2-1,t=Math.max(1.15/N,.012);if(k.startsWith('diamond')){let n=+(k.slice(7)||1),sp=1.48/n;for(let i=0;i<n;i++){let cx=-.74+sp*(i+.5),lx=(X-cx)*n;if(Math.abs(Math.abs(lx)+Math.abs(Y)-.62)<t*n)return(r+q)%2?2:3}return 0}if(k.startsWith('x')){let n=+(k.slice(1)||1),sp=1.55/n;for(let i=0;i<n;i++){let cx=-.775+sp*(i+.5),lx=(X-cx)*n;if(Math.min(Math.abs(lx-Y),Math.abs(lx+Y))<t*n)return(r+q)%2?3:2}return 0}return 0}function paint(k){mode=k;orig=null;for(let r=0;r<N;r++)for(let q=0;q<N;q++)g[r*N+q]=tile(r,q,k);render()}function main(){let t=S/N;x.fillStyle=C[0];x.fillRect(0,0,S,S);for(let r=0;r<N;r++)for(let q=0;q<N;q++){x.fillStyle=C[g[r*N+q]];x.fillRect(q*t,r*t,t+.2,t+.2)}pending=false}function render(){if(pending)return;pending=true;requestAnimationFrame(()=>{c.width=c.height=S;if(worker()){let a=g.slice();w.postMessage({i:++j,n:N,s:S,a:a.buffer},[a.buffer])}else main()})}function order(n){let a=[...Array(n).keys()];for(let i=n-1;i;i--){let k=Math.floor(Math.random()*(i+1));[a[i],a[k]]=[a[k],a[i]]}return a}function rearrangeRows(a){
 let out=new Uint8Array(N*N),rowOrder=order(N);
 for(let destRow=0;destRow<N;destRow++){
  let sourceRow=rowOrder[destRow];
  out.set(a.subarray(sourceRow*N,sourceRow*N+N),destRow*N);
 }
 return out;
}
function rearrangeColumns(a){
 let out=new Uint8Array(N*N),columnOrder=order(N);
 for(let row=0;row<N;row++){
  for(let destColumn=0;destColumn<N;destColumn++){
   let sourceColumn=columnOrder[destColumn];
   out[row*N+destColumn]=a[row*N+sourceColumn];
  }
 }
 return out;
}
function rearrangeCurrentArt(){
 let useRows=rowMode.checked,useColumns=columnMode.checked;
 if(!useRows&&!useColumns){st.textContent='Check Row, Column, or both';return}
 if(!orig&&!lm.checked)orig=g.slice();
 let next=g.slice();
 if(useRows)next=rearrangeRows(next);
 if(useColumns)next=rearrangeColumns(next);
 g=next;render();
 st.textContent=useRows&&useColumns?'Whole rows, then whole columns rearranged':useRows?'Whole horizontal rows rearranged':'Whole vertical columns rearranged';
}
function restore(){if(lm.checked)return paint(mode);if(orig){g=orig;orig=null;render()}}function save(){let s=lm.checked?1200:2000,o=document.createElement('canvas'),z=o.getContext('2d'),t=s/N;o.width=o.height=s;for(let r=0;r<N;r++)for(let q=0;q<N;q++){z.fillStyle=C[g[r*N+q]];z.fillRect(q*t,r*t,t+.2,t+.2)}o.toBlob(b=>{let a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=`WritersJumbler-Create-Studio-grid-${N}x${N}.png`;a.click()})}document.querySelectorAll('[data-t]').forEach(b=>b.onclick=()=>paint(b.dataset.t));document.getElementById('rearrange').onclick=rearrangeCurrentArt;document.getElementById('restore').onclick=restore;document.getElementById('save').onclick=save;lm.onchange=()=>{S=lm.checked?600:1000;lm.parentElement.classList.toggle('on',lm.checked);orig=null;render()};c.onclick=e=>{let b=c.getBoundingClientRect(),q=Math.floor((e.clientX-b.left)/b.width*N),r=Math.floor((e.clientY-b.top)/b.height*N);g[r*N+q]=g[r*N+q]?0:1;render()};paint('diamond1');