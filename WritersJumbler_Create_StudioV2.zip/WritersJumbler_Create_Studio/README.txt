Open START_HERE.html. Grids and Photo Effects use Web Workers, low memory mode, and row-only rearranging with no symmetry.
Both pages now have Row and Column checkboxes. Select Row only, Column only, both, or neither. Rearrange Selected follows the checked modes.

Corrected rearrangement: Whole Rows moves complete horizontal strips without changing squares inside them. Whole Columns moves complete vertical strips without changing squares inside them. Selecting both moves whole rows first and whole columns second. This applies to Create Studio and Photo Effects.
